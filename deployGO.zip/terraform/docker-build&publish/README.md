# Build Images and Publish to Docker Hub

### 1. docker cli should be available and configured before ahead

use the following command:-

```
terraform apply -auto-approve && terraform destroy -auto-approve
```